
public class testDate {

    public static void main(String[] args) {
        Date myDate = new Date();

        myDate.displayDate();

        // myDate.setDay(2);

        // myDate.setMonth(12);

        // myDate.setYear(2022);

        // myDate.displayDate();

        myDate.setDate(7, 20, 1996);

        myDate.displayDate();
    }
}