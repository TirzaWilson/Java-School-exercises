public class Date {

    private int day;

    private int month;

    private int year;

    public int getDay() {
        return day;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    // public void setDay(int newDay) {
    // this.day = newDay;
    // }

    // public void setMonth(int newMonth) {
    // this.month = newMonth;
    // }

    // public void setYear(int newYear) {
    // this.year = newYear;
    // }

    public void setDate(int newMonth, int newDay, int newYear) {
        this.month = newMonth;
        this.day = newDay;
        this.year = newYear;
    }

    public Date() {
        day = 12;
        month = 2;
        year = 2022;
    }

    public void displayDate() {
        System.out.printf("The date is %d/%d/%d \n", month, day, year);
    }
}